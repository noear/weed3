package weed3demo.config.utils;

/**
 * Created by yuety on 2017/7/22.
 */
public class TextUtils {
    public static boolean isEmpty(String str){
        return str == null || str.length()==0;
    }
}
