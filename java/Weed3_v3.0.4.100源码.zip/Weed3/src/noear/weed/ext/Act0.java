package noear.weed.ext;

/**
 * Created by noear on 14-6-11.
 */
public interface Act0 {
    public void run();
}
