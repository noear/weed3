package noear.weed.ext;

/**
 * Created by noear on 14-6-11.
 */
public interface Fun0<T> {
    public T run();
}
