package noear.weed.ext;

/**
 * Created by noear on 14-6-12.
 */
public interface Act1<P1> {
    public void run(P1 p1);
}
