package noear.weed.ext;

/**
 * Created by noear on 14-6-12.
 */
public interface Fun1<T,P1> {
    T run(P1 p1);
}
