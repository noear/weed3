package noear.weed.ext;

/**
 * Created by noear on 14-6-12.
 */
public interface Act2<P1,P2> {
    public void run(P1 p1, P2 p2);
}
