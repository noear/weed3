package noear.weed;

/**
 * Created by noear on 14-6-13.
 * 数据获取代理
 */
public interface GetHandler {
    Object get(String name);
}
