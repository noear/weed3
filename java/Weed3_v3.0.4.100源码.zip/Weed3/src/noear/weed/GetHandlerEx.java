package noear.weed;

/**
 * Created by yuety on 15/9/2.
 */
public interface GetHandlerEx {
    public Variate get(String key);
}
