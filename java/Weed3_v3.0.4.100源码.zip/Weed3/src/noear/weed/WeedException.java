package noear.weed;

/**
 * Created by noear on 14-7-7.
 * sdq 异常
 */
public class WeedException extends Exception {

    public WeedException(String message)
    {
        super(message);
    }
}
