package noear.weed;

/**
 * Created by noear on 14-6-12.
 * 作为缓存的主键
 */
public interface IWeedKey {
    public String getWeedKey();
}
